# Algo Trading Starter (Android)

A small Android starter app for strategy selection and risk settings. Supports market selection labels for NIFTY, BANK NIFTY and SENSEX and several strategy placeholders.

## Important status
- This is a prototype UI only.
- It does not contain real market data, a trading backend, broker API integration, or live order placement.
- The sample signal is not a real signal.
- Do not use this app to make trading decisions or assume it can earn profits.
- Live trading requires broker-specific integration, secure authentication, official instrument/contract data, risk controls, compliance review and extensive testing.

## Build APK without a laptop
1. Download this ZIP and extract it.
2. In Chrome, create a GitHub repository and upload the extracted project files.
3. In the repository, open **Actions** and run **Build Android APK** (or push to `main`).
4. Open the successful workflow run and download the `algo-trading-starter-debug-apk` artifact.
5. Extract the artifact ZIP on your Android phone; the APK inside is `app-debug.apk`.
6. Only install builds from your own repository after reviewing the code. This debug APK is a prototype, not a live trading app.

## Build locally
Requires JDK 17 and Gradle 8.9:
`gradle assembleDebug`
