package com.example.algoapp

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var market: Spinner
    private lateinit var strategy: Spinner
    private lateinit var mode: Spinner
    private lateinit var risk: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        fun heading(text: String, size: Float = 22f) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF172033.toInt())
                if (size >= 20) setTypeface(null, Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            })
        }
        fun label(text: String) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(0xFF4A5568.toInt())
                setPadding(0, 12, 0, 4)
            })
        }
        fun spinner(items: List<String>): Spinner {
            val s = Spinner(this)
            s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            root.addView(s, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            return s
        }
        fun button(text: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        heading("Algo Trading Starter")
        heading("NIFTY • BANK NIFTY • SENSEX", 16f)
        root.addView(TextView(this).apply {
            text = "Strategy research dashboard. This prototype does not connect to a broker or place real orders."
            textSize = 14f
            setTextColor(0xFF8A3B12.toInt())
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFF0DF.toInt())
        })

        label("Market")
        market = spinner(listOf("NIFTY (NSE)", "BANK NIFTY (NSE)", "SENSEX (BSE)"))
        label("Strategy")
        strategy = spinner(listOf(
            "EMA 12/26 + RSI 14",
            "VWAP trend confirmation",
            "Opening Range Breakout",
            "Supertrend + RSI",
            "MACD momentum",
            "Bollinger Bands mean reversion",
            "Support / resistance breakout",
            "ADX trend filter"
        ))
        label("Mode")
        mode = spinner(listOf("Paper trading (simulation)", "Signals only (manual review)"))
        label("Planned risk per trade (₹)")
        risk = EditText(this).apply {
            setText("250")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "250"
        }
        root.addView(risk, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        heading("Risk limits", 18f)
        root.addView(TextView(this).apply {
            text = "• Daily loss limit: ₹1,000\n• Maximum trades/day: 5\n• Option premium stop: 20%\n• Emergency stop: available in this prototype"
            textSize = 15f
            setTextColor(0xFF253047.toInt())
            setPadding(0, 4, 0, 10)
        })

        status = TextView(this).apply {
            text = "Status: simulation only — no broker connected"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF176B45.toInt())
            setPadding(0, 14, 0, 14)
        }
        root.addView(status)

        button("Generate sample signal") {
            val m = market.selectedItem.toString()
            val s = strategy.selectedItem.toString()
            status.text = "Sample only: $m • $s\nNo live market data used. No order placed."
        }
        button("Emergency stop (disable simulation actions)") {
            status.text = "STOPPED: no trading actions enabled. Restart the app to reset this demo."
        }
        button("Read live-trading requirements") {
            android.app.AlertDialog.Builder(this)
                .setTitle("Before live trading")
                .setMessage("This APK is a starter prototype only. Live orders require a supported broker API, secure authentication, official instrument data, compliant algo setup, server-side risk controls, and thorough testing. Never put broker passwords or API secrets in the APK.")
                .setPositiveButton("OK", null).show()
        }
    }
}
