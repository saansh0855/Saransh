# Live trading integration roadmap

Do not enable live orders until every item below is implemented and tested.

1. Select a broker with an officially supported API for the intended exchanges and index options.
2. Verify current SEBI/exchange/broker requirements for retail algorithmic trading, including any strategy registration, order tagging, static IP/hosting, rate limits and approvals that apply to the specific setup.
3. Use broker-supported authentication. Do not embed secrets in the APK or source repository.
4. Implement backend market-data adapter using official instrument/contract masters and current lot sizes/expiry data.
5. Implement signal calculation from timestamped candles and avoid look-ahead bias.
6. Implement server-side risk checks: max planned risk/trade, daily loss lockout, trade count, position/quantity checks, max order value, stale-data guard and kill switch.
7. Implement order state reconciliation for acknowledgements, partial fills, rejects, timeouts, cancel/replace and duplicate prevention.
8. Add persistent audit logs and alerts.
9. Backtest with realistic costs and walk-forward validation; then paper trade and broker sandbox/test environment if available.
10. Conduct security, failure-mode and compliance reviews before controlled live rollout.

Initial intended settings from user: planned risk ₹250/trade, daily loss limit ₹1,000, max 5 trades/day, option-premium stop 20%. These are not guaranteed maximum losses; slippage, gaps and execution failures can exceed them.
